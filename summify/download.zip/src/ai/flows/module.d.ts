// foo.d.ts
declare module 'jsdom';